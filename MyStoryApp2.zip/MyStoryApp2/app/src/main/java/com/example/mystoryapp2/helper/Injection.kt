package com.example.mystoryapp2.helper

import android.content.Context
import com.example.mystoryapp2.data.remote.paging.QuoteRepository
import com.example.mystoryapp2.data.remote.retrofit.ApiConfig

object Injection {
    fun provideRepository(context: Context, token: String): QuoteRepository {
        val apiService = ApiConfig.getApiService()
        return QuoteRepository(apiService, token)
    }
}