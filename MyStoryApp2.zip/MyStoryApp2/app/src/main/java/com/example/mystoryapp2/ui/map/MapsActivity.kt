package com.example.mystoryapp2.ui.map

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider
import com.example.mystoryapp2.R
import com.example.mystoryapp2.data.local.Story
import com.example.mystoryapp2.data.remote.Repository
import com.example.mystoryapp2.data.remote.response.AllStoriesWithLocation
import com.example.mystoryapp2.data.remote.retrofit.ApiConfig
import com.example.mystoryapp2.databinding.ActivityMapsBinding
import com.example.mystoryapp2.ui.ViewModelFactory
import com.example.mystoryapp2.ui.detail.DetailActivity
import com.example.mystoryapp2.ui.main.MainViewModel
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityMapsBinding
    private lateinit var mainViewModel: MainViewModel
    private var doubleBackToExitPressedOnce = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        mMap.uiSettings.isZoomControlsEnabled = true
        mMap.uiSettings.isIndoorLevelPickerEnabled = true
        mMap.uiSettings.isCompassEnabled = true
        mMap.uiSettings.isMapToolbarEnabled = true

        getStoryLocation()
    }

    private fun getStoryLocation() {
        mainViewModel = ViewModelProvider(
            this,
            ViewModelFactory(Repository.getInstance(dataStore))
        )[MainViewModel::class.java]

        mainViewModel.getStatus().observe(this) { status ->
            val listStories = ArrayList<Story>()
            val client = ApiConfig.getApiService().getStoriesWithLocation("Bearer ${status.token}")
            client.enqueue(object : Callback<AllStoriesWithLocation> {
                override fun onResponse(
                    call: Call<AllStoriesWithLocation>,
                    response: Response<AllStoriesWithLocation>
                ) {
                    if (response.isSuccessful) {
                        val responseBody = response.body()
                        if (responseBody != null) {
                            responseBody.listStory.forEach { account ->
                                val story = Story(
                                    account.name,
                                    account.photoUrl,
                                    account.createdAt,
                                    account.description,
                                    account.lat,
                                    account.lon
                                )
                                listStories.add(story)

                                mMap.addMarker(
                                    MarkerOptions()
                                        .position(LatLng(account.lat, account.lon))
                                        .title(account.name)
                                        .snippet(account.description)
                                )
                            }
                        }
                    }
                }

                override fun onFailure(call: Call<AllStoriesWithLocation>, t: Throwable) {
                    Log.e("Error", t.message.toString())
                }
            })

            if (doubleBackToExitPressedOnce) {
                val intentToDetail = Intent(this, DetailActivity::class.java)
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.map_options, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.normal_type -> {
                mMap.mapType = GoogleMap.MAP_TYPE_NORMAL
                true
            }
            R.id.satellite_type -> {
                mMap.mapType = GoogleMap.MAP_TYPE_SATELLITE
                true
            }
            R.id.terrain_type -> {
                mMap.mapType = GoogleMap.MAP_TYPE_TERRAIN
                true
            }
            R.id.hybrid_type -> {
                mMap.mapType = GoogleMap.MAP_TYPE_HYBRID
                true
            }
            else -> {
                super.onOptionsItemSelected(item)
            }
        }
    }

    private val requestPermissionLauncher =
        registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { isGranted: Boolean ->
            if (isGranted) {
                getMyLocation()
            }
        }

    private fun getMyLocation() {
        if (ContextCompat.checkSelfPermission(
                this.applicationContext,
                android.Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            mMap.isMyLocationEnabled = true
        } else {
            requestPermissionLauncher.launch(android.Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }
}