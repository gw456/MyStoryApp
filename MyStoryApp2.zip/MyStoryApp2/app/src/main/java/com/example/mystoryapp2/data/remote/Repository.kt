package com.example.mystoryapp2.data.remote

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import com.example.mystoryapp2.data.local.Status
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.map

class Repository private constructor(
    private val dataStore: DataStore<Preferences>
    ){

    suspend fun saveStatus(status: Status) {
        dataStore.edit { preferences ->
            preferences[TOKEN] = status.token
            preferences[STATE_KEY] = status.isLogin
        }
    }

    fun getStatus() : Flow<Status> {
        return dataStore.data.map { preferences ->
            Status(
                preferences[TOKEN] ?: "",
                preferences[STATE_KEY] ?: false
            )
        }
    }

    suspend fun logout() {
        dataStore.edit { preferences ->
            preferences[TOKEN] = ""
            preferences[STATE_KEY] = false
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: Repository? = null

        private val TOKEN = stringPreferencesKey("token")
        private val STATE_KEY = booleanPreferencesKey("state")

        fun getInstance(dataStore: DataStore<Preferences>): Repository {
            return INSTANCE ?: synchronized(this) {
                val instance = Repository(dataStore)
                INSTANCE = instance
                instance
            }
        }
    }
}