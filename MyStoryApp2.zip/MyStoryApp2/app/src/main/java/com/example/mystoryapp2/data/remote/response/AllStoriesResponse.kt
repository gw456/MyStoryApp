package com.example.mystoryapp2.data.remote.response

import com.example.mystoryapp2.data.local.ListStoryItem
import com.google.gson.annotations.SerializedName

data class AllStoriesResponse(

	@field:SerializedName("listStory")
	val listStory: List<ListStoryItem> = emptyList(),

	@field:SerializedName("error")
	val error: Boolean = false,

	@field:SerializedName("message")
	val message: String = ""
)
