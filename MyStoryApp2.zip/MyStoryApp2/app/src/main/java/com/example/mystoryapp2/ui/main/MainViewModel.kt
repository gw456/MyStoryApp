package com.example.mystoryapp2.ui.main

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.example.mystoryapp2.data.remote.Repository
import com.example.mystoryapp2.data.local.Status
import kotlinx.coroutines.launch

class MainViewModel(private val pref: Repository) : ViewModel() {
    fun getStatus(): LiveData<Status> {
        return pref.getStatus().asLiveData()
    }

    fun logout() {
        viewModelScope.launch {
            pref.logout()
        }
    }
}