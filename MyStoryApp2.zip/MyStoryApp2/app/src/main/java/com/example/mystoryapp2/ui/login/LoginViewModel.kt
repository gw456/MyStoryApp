package com.example.mystoryapp2.ui.login

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.mystoryapp2.data.local.Status
import com.example.mystoryapp2.data.remote.Repository
import kotlinx.coroutines.launch

class LoginViewModel(private val pref: Repository) : ViewModel() {
    fun saveStatus(status: Status) {
        viewModelScope.launch {
            pref.saveStatus(status)
        }
    }
}