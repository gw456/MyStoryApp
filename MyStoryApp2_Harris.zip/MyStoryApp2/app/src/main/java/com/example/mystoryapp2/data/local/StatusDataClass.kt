package com.example.mystoryapp2.data.local

data class StatusDataClass (
    val token: String,
    val isLogin: Boolean
)